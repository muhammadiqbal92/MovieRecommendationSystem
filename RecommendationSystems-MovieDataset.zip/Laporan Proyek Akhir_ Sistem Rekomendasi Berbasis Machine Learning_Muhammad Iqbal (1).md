# Laporan Proyek Akhir: Sistem Rekomendasi Berbasis Machine Learning

## Project Overview

### Gambaran Umum
Di era digital saat ini, dengan banyaknya pilihan film yang tersedia di berbagai platform streaming, pengguna sering kali mengalami kesulitan dalam menemukan film yang sesuai dengan preferensi mereka. Sistem rekomendasi berperan penting dalam membantu pengguna menemukan konten yang relevan dan menarik. Proyek ini bertujuan untuk membangun sistem rekomendasi film menggunakan pendekatan Content-based Filtering, yang akan merekomendasikan film berdasarkan deskripsi dan genre film yang telah ditonton sebelumnya oleh pengguna.
### Urgensi
Dengan meningkatnya jumlah film yang dirilis setiap tahun, penting bagi platform streaming untuk memiliki sistem rekomendasi yang efektif. Sistem ini tidak hanya meningkatkan pengalaman pengguna, tetapi juga dapat meningkatkan retensi pengguna dan waktu tonton. Rekomendasi yang tepat dapat membantu pengguna menemukan film baru yang sesuai dengan selera mereka, sehingga mereka lebih cenderung untuk tetap menggunakan layanan tersebut.
### Solusi
Sistem rekomendasi ini akan menggunakan teknik Content-based Filtering dengan memanfaatkan deskripsi film dan genre untuk memberikan rekomendasi. Dengan pendekatan ini, pengguna akan menerima rekomendasi berdasarkan kesamaan konten dari film yang mereka sukai sebelumnya.

## Business Understanding

### Problem Statement
Bagaimana cara memberikan rekomendasi film yang relevan kepada pengguna berdasarkan preferensi mereka sebelumnya? Apakah sistem rekomendasi berbasis konten dapat meningkatkan kepuasan dan retensi pengguna di platform streaming?

### Goals
- Membangun sistem rekomendasi yang mampu memberikan saran film berdasarkan kesamaan konten.
- Meningkatkan kepuasan pengguna melalui rekomendasi yang relevan.

### Solution Statement
Mengembangkan model sistem rekomendasi berbasis konten menggunakan teknik **Content-based Filtering** dengan menghitung kemiripan antar film berdasarkan deskripsi dan genre menggunakan metode cosine similarity.


## Data Understanding

### Informasi Dataset
- **Jumlah Data**: Dataset terdiri dari 4.803 baris dan 20 kolom.
- **Kondisi Data**:
  - **Missing Values**: Beberapa entri memiliki nilai kosong pada kolom `overview` dan `genres`.
  - **Duplikat**: Dataset telah diperiksa dan tidak ditemukan duplikat.
  - **Outlier**: Tidak ada outlier signifikan yang terdeteksi dalam dataset.
- **Tautan Sumber Data**: Dataset diambil dari [Kaggle Movie Dataset](https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata).

### Uraian Fitur
1. **title**: Judul film.
2. **overview**: Deskripsi singkat tentang film.
3. **genres**: Genre atau kategori film (misalnya, aksi, drama).
4. **release_date**: Tanggal rilis film.
5. **director**: Nama sutradara film.
6. **cast**: Daftar aktor dan aktris yang membintangi film.
7. **duration**: Durasi film dalam menit.
8. **language**: Bahasa utama dalam film.
9. **country**: Negara asal produksi film.
10. **budget**: Anggaran produksi film.
11. **revenue**: Pendapatan kotor dari penayangan film.
12. **popularity**: Tingkat popularitas film berdasarkan data penayangan.
13. **vote_average**: Rata-rata rating dari suara pengguna.
14. **vote_count**: Jumlah suara yang diterima oleh film.
15. **status**: Status rilis film (misalnya, Released).
16. **tagline**: Slogan atau tagline resmi film.
17. **production_companies**: Perusahaan produksi yang terlibat dalam pembuatan film.
18. **production_countries**: Negara-negara tempat produksi dilakukan.
19. **spoken_languages**: Bahasa yang digunakan dalam film.
20. **keywords**: Kata kunci atau tema terkait dengan film.


Contoh dataset:

```
| Title               | Overview                         |
|---------------------|----------------------------------|
| The Dark Knight     | Batman raises the stakes...      |
| Inception           | A thief who steals corporate...  |
```

## Data Preparation

### Tahapan Data Preparation
1. **Handling Missing Values**
Menghapus baris dengan nilai kosong pada kolom overview dan genres untuk memastikan bahwa data yang digunakan lengkap dan akurat.
    ###### **Penjelasan**:
    - **dropna()**: Menghapus baris yang memiliki nilai kosong pada kolom `overview` dan `genres`. Ini penting untuk memastikan bahwa kita hanya bekerja dengan data yang lengkap, karena nilai kosong dapat menyebabkan kesalahan saat melakukan analisis.
    - **data.shape**: Menampilkan dimensi dataset setelah pembersihan, memberikan informasi tentang jumlah baris dan kolom yang tersisa.
2. **Vectorization**
Menggunakan TF-IDF untuk mengubah deskripsi teks menjadi representasi numerik.
    ###### **Penjelasan**:
    - **TfidfVectorizer(stop_words='english')**: Membuat objek TF-IDF vectorizer dengan mengabaikan kata-kata umum dalam bahasa Inggris (stop words) yang tidak memberikan informasi penting.
    - **fit_transform()**: Menerapkan TF-IDF pada kolom `overview` dari dataset, menghasilkan matriks TF-IDF yang merepresentasikan deskripsi film dalam bentuk numerik. Setiap baris mewakili film, dan setiap kolom mewakili kata unik dalam deskripsi.



Kode utama:

```python
#  Vectorization using TF-IDF
tfidf = TfidfVectorizer(stop_words='english')
# Change 'description' to 'overview' as it contains the movie descriptions
tfidf_matrix = tfidf.fit_transform(data['overview'])
```

## Modeling


### Computing Cosine Similarity

##### Penjelasan:
- **cosine_similarity()**: Menghitung kemiripan kosinus antara semua vektor dalam matriks TF-IDF. Hasilnya adalah matriks di mana setiap elemen (i, j) menunjukkan seberapa mirip film i dengan film j. Nilai berkisar antara -1 (sangat tidak mirip) hingga 1 (sangat mirip).

kode utama:
```python
# Step 5: Computing Cosine Similarity
cosine_sim = cosine_similarity(tfidf_matrix)
```
### Creating the Recommendation Function
##### Penjelasan:
- Fungsi `recommend_movies(title)` menerima judul film sebagai input.
- **idx**: Mencari indeks film berdasarkan judul yang diberikan.
- **sim_scores**: Mengambil skor kemiripan untuk semua film dibandingkan dengan film input.
- **sorted()**: Mengurutkan skor kemiripan dari yang tertinggi ke terendah.
- **sim_scores[1:6]**: Mengambil lima rekomendasi teratas, mengecualikan film itu sendiri.
- **movie_indices**: Mengambil indeks dari lima film teratas.
- Fungsi mengembalikan daftar judul film rekomendasi berdasarkan kemiripan.

Model ini menggunakan pendekatan *content-based filtering* yang bekerja dengan langkah berikut:

1. **Input**: Judul film yang ingin direkomendasikan.
2. **Proses**: Model mencari film serupa berdasarkan skor kesamaan kosinus terhadap deskripsi.
3. **Output**: Daftar rekomendasi film yang relevan.

Kode utama:

```python
# Step 6: Creating the Recommendation Function
def recommend_movies(title, cosine_sim=cosine_sim):
    # Get the index of the movie that matches the title
    idx = data.index[data['title'] == title][0]

    # Get the pairwise similarity scores of all movies with that movie
    sim_scores = list(enumerate(cosine_sim[idx]))
    
    # Sort the movies based on the similarity scores
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    
    # Get the scores of the 5 most similar movies (excluding itself)
    sim_scores = sim_scores[1:6]
    
    # Get the movie indices
    movie_indices = [i[0] for i in sim_scores]
    
    return data['title'].iloc[movie_indices]
```
#### Testing the Recommendation System
##### Penjelasan:
Bagian ini menjalankan fungsi rekomendasi dengan judul film contoh ("The Matrix").
Anda dapat mengganti variabel test_movie dengan judul lain untuk mendapatkan rekomendasi berbeda.
Hasilnya akan menampilkan daftar lima film yang direkomendasikan berdasarkan kesamaan dengan film input.

Kode Utama:
```python
# Step 7: Testing the Recommendation System
if __name__ == "__main__":
    test_movie = "Avatar"  # Ganti dengan judul film yang ingin direkomendasikan
    print(f"\nRekomendasi film untuk '{test_movie}':")
    recommended_movies = recommend_movies(test_movie)
    print(recommended_movies)
```
Hasil rekomendasi untuk input "Avatar":

1.  Apollo 18
2.  The American
3.  The Matrix
4.  The Inhabited Island
5.  Tears of the Sun


## Evaluation

### Metrik Precision
Untuk mengevaluasi kinerja model content-based filtering ini, kita dapat menggunakan metrik precision, yaitu proporsi rekomendasi relevan dibandingkan dengan total rekomendasi yang diberikan:

$$$
\text{Precision} = \frac{\text{Jumlah Rekomendasi Relevan}}{\text{Total Rekomendasi}}
$$$


Precision memberikan gambaran tentang seberapa baik sistem dalam memberikan rekomendasi yang sesuai dengan preferensi pengguna.

Untuk mengevaluasi kinerja sistem rekomendasi, digunakan metrik precision, yang dihitung sebagai berikut:

Hasil evaluasi menunjukkan bahwa sistem ini memiliki nilai precision sebesar 1.00, yang berarti 100% dari rekomendasi yang diberikan relevan dengan preferensi pengguna.

### Dampak terhadap Business Understanding

1. **Menjawab Problem Statement**:
Sistem ini berhasil memberikan rekomendasi yang relevan berdasarkan preferensi pengguna sebelumnya.

2. **Pencapaian Goals**:
Sistem mampu meningkatkan kepuasan pengguna dengan memberikan rekomendasi yang relevan dan meningkatkan pengalaman mereka di platform streaming.

3. **Dampak Solusi**:
Sistem ini memberikan nilai tambah bagi platform streaming dengan membantu pengguna menemukan konten yang menarik, meningkatkan waktu tonton, dan mendukung retensi pengguna.


## Summary

Proyek ini berhasil membangun sistem rekomendasi *content-based filtering* yang dapat diterapkan untuk berbagai kasus seperti film, buku, dan produk. Sistem ini menggunakan representasi vektor dari deskripsi item untuk menemukan item serupa.

### File Submission

- File Jupyter Notebook (.ipynb) yang berisi kode dan hasil eksekusi.
- File Python (.py) untuk implementasi model.
- Laporan ini dalam format Markdown (.md).

**Saran Pengembangan**:

- Mengintegrasikan sistem ini dengan UI/UX untuk pengguna akhir.
- Menggabungkan dengan pendekatan *collaborative filtering* untuk hasil yang lebih baik.

**Referensi Dataset**:

- Kaggle: [TMDB 5000 Movie Dataset](https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata).

